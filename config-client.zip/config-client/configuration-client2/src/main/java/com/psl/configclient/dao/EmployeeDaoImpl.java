package com.psl.configclient.dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.psl.configclient.config.entity.Report;
@Repository
public class EmployeeDaoImpl  implements EmployeeDao{
	
	
	@Autowired
	private JdbcTemplate jdbc;


	@Override
	public List<String> fetchtKey(List<Map<String,Object>> list){
		
		List<String> columns=new ArrayList<>();
		for(Map<String,Object> map: list){
			for(Map.Entry<String,Object> entry :map.entrySet()){
				
				
				columns.add(entry.getKey());
			}
			break;
		}
		
		for(String cols:columns){
			System.out.println(cols);
		}
		
		return columns;
	}
	
	@Override
	public 	List<Map<String,Object>> reportGenerator(Report theReport) {
		 
		List<Map<String,Object>> list=new ArrayList<>();
		
		String query=theReport.getQuery();
		String table=theReport.getTable();
		List<String> columns=theReport.getColumns();
		
		
	
		
		if(!query.isEmpty()){
		
			list=jdbc.queryForList(query);
		}
			
	
		else if(table !=null & columns!=null)
		{
			String col_list=String.join(",", columns);
			String query1="select " +col_list + " from "+ table;
			list=jdbc.queryForList(query1);
			
		}
	
	
		
		return list;
	}
}