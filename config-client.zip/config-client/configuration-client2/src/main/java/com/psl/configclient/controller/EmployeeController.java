package com.psl.configclient.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.psl.configclient.config.entity.Report;
import com.psl.configclient.excel.ExcelGenerator;
import com.psl.configclient.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired 
	private EmployeeService service;
	

	
	public EmployeeController(EmployeeService theservice) {
		service=theservice;
	}
	
	
	
	
	
	@RequestMapping("/test")
	public String  hello()
	{
		return "hello";
		
	}
	
	
	
	
	
	@PostMapping("/report")
	public List<Map<String,Object>> generate(@RequestBody Report theReport)
	{
		
		return service.reportGenerator(theReport);
	}
//	
//	@PostMapping("/download")
//	public List<String> downloadExcel(@RequestBody Report theReport)
//	{
//		List<Map<String,Object>> list=service.reportGenerator(theReport);
//		
//		return service.fetchtKey(list);
//	}
//	
	
	@PostMapping("/download")
    public ResponseEntity<InputStreamResource> excelCustomersReport(@RequestBody Report theReport) throws IOException {
		List<Map<String,Object>> list=service.reportGenerator(theReport);
    
    ByteArrayInputStream in=null;
	try {
		in = ExcelGenerator.toExcel(list);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    // return IOUtils.toByteArray(in);
    
    HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=report.xlsx");
    
     return ResponseEntity
                  .ok()
                  .headers(headers)
                  .body(new InputStreamResource(in));
    }
	
}